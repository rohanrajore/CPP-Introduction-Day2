//
// Account.h
//

class Account
{
public:
	void deposit(double amount);
	void withdraw(double amount);
	double get_balance();

protected:
	bool validate();

private:
	double balance;
};


