#pragma once

class Person
{
public:
	Person(void);
	Person(int a, double h);
	~Person(void);
	void set_age(int a);
	void set_height(double h);
	int get_age();
	double get_height();
	void Display() const;
private:
	int age;
	double height;
};