#pragma once
#include "Person.h"

class Adult : public Person
{
public:
	Adult(void);
	Adult(int a, double h, bool s);
	~Adult(void);
	void set_smoker(bool s);
	bool is_smoker();
	void Display()const;
private:
	bool smokes;
};
