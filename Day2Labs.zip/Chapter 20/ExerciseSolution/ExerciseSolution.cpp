#include <iostream>
#include "Person.h"
#include "Boss.h"
#include "Worker.h"
using namespace std;

int main(int argc, char** argv)
{
	Person p("Fred Flintstone",99,'M');
	Worker w("Barney Rubble",88,'M',6.5f,100);
	Boss b("Wilma Flintstone",66, 'F',1000);

	p.Display();
	w.Display();
	b.Display();
	
	return 0;

}
