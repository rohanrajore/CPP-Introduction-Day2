#include "Person.h"

Person::Person(void)
{
	age = 0;
	height = 0;
}

Person::~Person(void)
{
}

void Person::set_age(int a)
{
	age = a;
	height = 0;
}

void Person::set_height(double h)
{
	height = h;
}

int Person::get_age()
{
	return age;
}

double Person::get_height()
{
	return height;
}


