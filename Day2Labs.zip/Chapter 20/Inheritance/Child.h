#pragma once
#include "Person.h"

class Child : public Person
{
public:
	Child(void);
	~Child(void);
	void set_sex(char s);
	char get_sex();
private:
	char sex;
};


