#pragma once
#include "Person.h"

class Adult : public Person
{
public:
	Adult(void);
	~Adult(void);
	void set_smoker(bool s);
	bool is_smoker();
private:
	bool smokes;
};



