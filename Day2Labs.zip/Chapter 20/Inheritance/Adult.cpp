#include "Adult.h"

Adult::Adult(void)
{
	smokes = false;
}

Adult::~Adult(void)
{
}

void Adult::set_smoker(bool s)
{
	smokes = s;
}

bool Adult::is_smoker()
{
	return smokes;
}



