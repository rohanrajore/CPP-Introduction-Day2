//
// ATM Class definition
//

class atm
{
public:
	// constructors and destructors
	atm();
	atm(double opening_balance);
	atm(double opening_balance, const char* holder_name);
	~atm();
public:
	// modifier functions
	double Deposit(double amount);
	double Deposit(double amount, bool cheque);
	double Withdraw(double amount);
	double BillPay(double amount, int towho);
public:
	// query functions
	double GetBalance() const;
private:
	// private functions
	bool validate(double amount);
private:
	// data
	double balance;
	char* account_holder;
};



