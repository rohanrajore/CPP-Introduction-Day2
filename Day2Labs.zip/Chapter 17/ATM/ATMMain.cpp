#include <iostream>
#include "ATM.h"
using namespace std;

int main(int argc, char** argv)
{
	atm mybank(10);
	double amount = 500.00;
	bool cheque = false;

	cout << mybank.Deposit(amount) << endl;
	cheque = true;
	amount = 250.00;
	cout << mybank.Deposit(amount,cheque) << endl;
	amount = 50.0;
	cout << mybank.Withdraw(amount) << endl;
	
	return 0;
}
