#include <iostream>
#include <string>

namespace NS 
{
	class A {};

	void f(A& a, int i) {}

}  // namespace NS

int main() 
{
   	NS::A a;
   	f(a, 0);  // Calls NS::f.
   	std::string str = "hello world";
  	std::cout << str;	// overloaded << operator for string
  						// is actually in the std namespace
  	std::cout << std::endl;
}
