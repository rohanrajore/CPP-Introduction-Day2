#include<iostream>
 using namespace std;
 class A
 {
 private:
     class B
     {
     public:
         void display()
         {
             cout<<"Nested class"<<endl;
         }
     };
     B inner;
 public:
     void show()
     {
         inner.display();
     }
 };
 
 int main()
 {
     A outer;
     outer.show();
     return 0;   
 }
 
 
 
