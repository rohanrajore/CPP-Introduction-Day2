#include <iostream>
#include "Person.h"
using namespace std;

int main(int argc, char** argv)
{
	Person me;
	Person him("Fred Flintstone",999,'M');
	Person* her = new Person("Wilma Flintstone",888,'F');

	me.Display();
	him.Display();
	her->Display();

	delete her;
}
