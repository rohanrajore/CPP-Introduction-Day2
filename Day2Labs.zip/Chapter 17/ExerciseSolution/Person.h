#pragma once

class Person
{
public:
	Person(void);
	Person(const char* name, int age, char sex);
	~Person(void);
	void Display()const;
private:
	char* name;
	int age;
	char sex;
};

