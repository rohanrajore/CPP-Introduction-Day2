//
// Implementation of the ATM class
//
#include "Chained.h"
#include <iostream>
#include <cstring>
using namespace std;

atm::atm()
	: atm(0) {}

atm::atm(double opening_balance)
	: atm(opening_balance, "Unknown") {}

atm::atm(double opening_balance, const char* holder_name)
	: balance(opening_balance)
{
	account_holder = new char[255];
	strcpy(account_holder, holder_name);
}

atm::~atm()
{
	delete[] account_holder;
}

double atm::deposit(double amount)
{
	balance += amount;
	return balance;
}

double atm::deposit(double amount, bool cheque)
{
	balance += amount;
	balance -= 0.5; // charge for cheque
	return balance;
}

double atm::withdraw(double amount)
{
	if (validate(amount))
	{
		balance -= amount;
	}
	return balance;
}

double atm::billpay(double amount, int towho)
{
	if (validate(amount))
	{
		balance -= amount;
	}
	return balance;
}

double atm::getbalance() const
{
	return balance;
}

bool atm::validate(double amount)
{
	return ((balance - amount) > 0);
}

