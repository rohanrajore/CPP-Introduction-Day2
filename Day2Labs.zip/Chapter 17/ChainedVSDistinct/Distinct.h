#pragma once
//
// ATM Class definition
//

class automatedTellerMachine
{
public:
	// constructors and destructors
	automatedTellerMachine();
	automatedTellerMachine(double opening_balance);
	automatedTellerMachine(double opening_balance, const char* holder_name);
	~automatedTellerMachine();
public:
	// modifier functions
	double deposit(double amount);
	double deposit(double amount, bool cheque);
	double withdraw(double amount);
	double billpay(double amount, int towho);
public:
	// query functions
	double getbalance() const;
private:
	// private functions
	bool validate(double amount);
private:
	// data
	double balance;
	char* account_holder;
};

