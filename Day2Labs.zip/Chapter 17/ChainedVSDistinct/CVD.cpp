#include <iostream>
#include "Chained.h"
#include "Distinct.h"
#include <time.h>
using namespace std;

int main(int argc, char** argv)
{
	clock_t starttime;
	clock_t stoptime;
	
	starttime = clock();
	for (int x = 0; x < 1000000000; ++x)
	{
		atm mybank;
	}
	stoptime = clock();
	cout << "1 billion creations using chained constructors took "
		<< ((stoptime - starttime)/1000000.0) << " seconds\n";


	starttime = clock();
	for (int x = 0; x < 1000000000; ++x)
	{
		automatedTellerMachine mybank;
	}
	stoptime = clock();
	cout << "1 billion creations using distinct constructors took "
		<< ((stoptime - starttime)/1000000.0) << " seconds\n";
}
