#pragma once
//
// ATM Class definition
//

class atm
{
public:
	// constructors and destructors
	atm();
	atm(double opening_balance);
	atm(double opening_balance, const char* holder_name);
	~atm();
public:
	// modifier functions
	double deposit(double amount);
	double deposit(double amount, bool cheque);
	double withdraw(double amount);
	double billpay(double amount, int towho);
public:
	// query functions
	double getbalance() const;
private:
	// private functions
	bool validate(double amount);
private:
	// data
	double balance;
	char* account_holder;
};
