//
// Implementation of the ATM class
//
#include "Distinct.h"
#include <iostream>
#include <cstring>
using namespace std;

automatedTellerMachine::automatedTellerMachine()
	: balance(0)
{
	account_holder = new char[255];
	strcpy(account_holder, "Unknown");
}

automatedTellerMachine::automatedTellerMachine(double opening_balance)
	: balance(opening_balance)
{
	account_holder = new char[255];
	strcpy(account_holder, "Unknown");
}

automatedTellerMachine::automatedTellerMachine(double opening_balance, const char* holder_name)
	: balance(opening_balance)
{
	account_holder = new char[255];
	strcpy(account_holder, holder_name);
}

automatedTellerMachine::~automatedTellerMachine()
{
	delete[] account_holder;
}

double automatedTellerMachine::deposit(double amount)
{
	balance += amount;
	return balance;
}

double automatedTellerMachine::deposit(double amount, bool cheque)
{
	balance += amount;
	balance -= 0.5; // charge for cheque
	return balance;
}

double automatedTellerMachine::withdraw(double amount)
{
	if (validate(amount))
	{
		balance -= amount;
	}
	return balance;
}

double automatedTellerMachine::billpay(double amount, int towho)
{
	if (validate(amount))
	{
		balance -= amount;
	}
	return balance;
}

double automatedTellerMachine::getbalance() const
{
	return balance;
}

bool automatedTellerMachine::validate(double amount)
{
	return ((balance - amount) > 0);
}

