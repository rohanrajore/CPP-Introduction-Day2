#include<iostream>
 using namespace std;
 class A
 {
 public:
     class B
     {
     public:
         void display();
     };
 };
 
 void A::B::display()
 {
     cout<<"Nested class"<<endl;
 }
 
 int main()
 {
     A::B inner;
     inner.display();
     return 0;   
 }
 
 
