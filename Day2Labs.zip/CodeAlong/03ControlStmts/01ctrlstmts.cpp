// Requirements
// Ask the user how many students (minimum 1).

// For each student:
// Read marks (0–100)

// If marks are invalid, skip that student (continue)

// Assign a grade using switch:
// 90–100 → A
// 75–89 → B
// 50–74 → C
// < 50 → F

// Store all valid marks.

// After input:
// Print all marks using a range-based for loop

// Find the average using a for loop

// Use:
// while loop to control input
// do-while to repeat the program

// Use:
// break to exit early if user enters -1

// Use:
// ternary operator to print Pass / Fail

#include <iostream>
using namespace std;

int main() {
    char choice;

    do {   // DO-WHILE
        int n;
        cout << "Enter number of students: ";
        cin >> n;

        if (n <= 0) {   // IF
            cout << "Invalid number\n";
            continue;
        }

        int marks[100];
        int count = 0;
        int i = 0;

        while (i < n) {   // WHILE
            int m;
            cout << "Enter marks (0–100) for student " << i + 1
                 << " (-1 to stop): ";
            cin >> m;

            if (m == -1) {   // IF + BREAK
                break;
            }

            if (m < 0 || m > 100) {   // IF + CONTINUE
                cout << "Invalid marks, skipping\n";
                continue;
            }

            marks[count++] = m;

            // SWITCH
            switch (m / 10) {
                case 10:
                case 9:
                    cout << "Grade: A\n";
                    break;
                case 8:
                case 7:
                    cout << "Grade: B\n";
                    break;
                case 6:
                case 5:
                    cout << "Grade: C\n";
                    break;
                default:
                    cout << "Grade: F\n";
            }

            i++;
        }

        cout << "\nAll valid marks:\n";
        int sum = 0;

        // RANGE-BASED FOR
        for (int m : marks) {
            if (sum == count * 100) break; // safety
        }

        // FOR loop
        for (int j = 0; j < count; j++) {
            cout << marks[j] << " ";
            sum += marks[j];
        }

        cout << endl;

        double avg = (count > 0) ? (double)sum / count : 0;  // TERNARY
        cout << "Average = " << avg << endl;

        cout << "Result: " << (avg >= 50 ? "PASS" : "FAIL") << endl;

        cout << "\nRun again? (y/n): ";
        cin >> choice;

    } while (choice == 'y' || choice == 'Y');  // DO-WHILE

    return 0;
}
