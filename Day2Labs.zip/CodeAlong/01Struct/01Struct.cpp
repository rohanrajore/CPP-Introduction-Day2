#include <iostream>
#include <string>
using namespace std;

/*
----------------------------------------------------
STRUCTURES IN C++
----------------------------------------------------

This file covers:
1. What a struct is
2. Declaring a struct
3. Creating struct variables
4. Accessing members
5. Initializing structs
6. Nested structures
7. Array of structures
8. struct vs class (basic idea)
----------------------------------------------------
*/

// 1️⃣ Simple structure
struct Person {
    string name;
    int age;
};

// 2️⃣ Another structure
struct Address {
    string city;
    int pincode;
};

// 3️⃣ Nested structure
struct Student {
    string name;
    Address addr;   // nested struct
};

int main() {

    cout << "----- BASIC STRUCT -----\n";
    // 4️⃣ Creating and assigning values
    Person p1;
    p1.name = "Alice";
    p1.age = 25;

    cout << "Name: " << p1.name << ", Age: " << p1.age << endl;

    cout << "\n----- STRUCT INITIALIZATION -----\n";
    // 5️⃣ Initialization at creation
    Person p2 = {"Bob", 30};
    cout << "Name: " << p2.name << ", Age: " << p2.age << endl;

    cout << "\n----- NESTED STRUCT -----\n";
    Student s1;
    s1.name = "Charlie";
    s1.addr.city = "Bangalore";
    s1.addr.pincode = 560001;

    cout << "Student: " << s1.name << endl;
    cout << "City: " << s1.addr.city << endl;
    cout << "Pincode: " << s1.addr.pincode << endl;

    cout << "\n----- ARRAY OF STRUCTS -----\n";
    Person people[3] = {
        {"David", 40},
        {"Eva", 35},
        {"Frank", 28}
    };

    // for (int i = 0; i < 3; i++) {
    //     cout << "Person " << i + 1 << ": "
    //          << people[i].name << ", "
    //          << people[i].age << endl;
    // }

    // cout << "\n----- STRUCT vs CLASS (BASIC IDEA) -----\n";
    // cout << "struct: members are public by default\n";
    // cout << "class : members are private by default\n";

    return 0;
}
