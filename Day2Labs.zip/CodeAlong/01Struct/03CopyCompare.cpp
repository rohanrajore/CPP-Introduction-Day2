#include <iostream>
#include <string>
using namespace std;

struct Person {
    string name = "Unknown";
    int age = 0;
};

int main() {

    // ---------- Assignment & Copying ----------
    Person p1 = {"Alice", 25};
    Person p2 = p1;   // copy entire struct (member-by-member)

    cout << "p1: " << p1.name << ", " << p1.age << endl;
    cout << "p2: " << p2.name << ", " << p2.age << endl;

    // Modify p2 to show they are independent copies
    p2.age = 30;

    cout << "\nAfter modifying p2:\n";
    cout << "p1 age: " << p1.age << endl;
    cout << "p2 age: " << p2.age << endl;

    // ---------- Comparison (manual) ----------
    if (p1.name == p2.name && p1.age == p2.age) {
        cout << "\nPersons are equal\n";
    } else {
        cout << "\nPersons are NOT equal\n";
    }

    // ---------- const struct ----------
    const Person p3 = {"Bob", 40};

    cout << "\np3: " << p3.name << ", " << p3.age << endl;

    // p3.age = 50;   // ❌ ERROR: cannot modify a const struct

    return 0;
}
