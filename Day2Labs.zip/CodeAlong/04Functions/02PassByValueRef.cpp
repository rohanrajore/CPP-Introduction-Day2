#include <iostream>
using namespace std;

// ---------- FUNCTION DECLARATIONS ----------
void incrementByValue(int x);    // pass by value
void incrementByReference(int& x); // pass by reference

int main() {

    int a = 10;
    int b = 10;

    cout << "Before function calls:\n";
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;

    // ---------- PASS BY VALUE ----------
    incrementByValue(a);

    cout << "\nAfter incrementByValue(a):\n";
    cout << "a = " << a << "  (unchanged)\n";

    // ---------- PASS BY REFERENCE ----------
    incrementByReference(b);

    cout << "\nAfter incrementByReference(b):\n";
    cout << "b = " << b << "  (changed)\n";

    return 0;
}

// ---------- FUNCTION DEFINITIONS ----------

void incrementByValue(int x) {
    x = x + 1;
    cout << "Inside incrementByValue, x = " << x << endl;
}

void incrementByReference(int& x) {
    x = x + 1;
    cout << "Inside incrementByReference, x = " << x << endl;
}
