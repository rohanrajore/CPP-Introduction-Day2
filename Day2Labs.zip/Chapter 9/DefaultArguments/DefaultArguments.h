//
// prototype definition demonstrating 
// optional function arguments
//

void Print(int number_of_pages, int copies = 1);
