//
// Example function
//

bool Is_Leap_Year(int year)

{
	bool ly;

	ly = (year %4 ==0) &&
		 (year %100 != 0 || year %400 ==0);
	
	return ly;
}


