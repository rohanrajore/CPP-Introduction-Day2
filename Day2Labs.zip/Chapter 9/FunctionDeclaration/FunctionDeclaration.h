//
// Sample function declarations
//

int adder(int num1, int num2);
int subtrct(int, int);
int ranno();
void printnum(double n);
void func1();
void func2(void);
