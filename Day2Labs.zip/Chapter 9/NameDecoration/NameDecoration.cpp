int sum(int x, int y)
{
	return x + y;
}

double sum(double x, double y)
{
	return x + y;
}

int main(int argc, char** argv)
{
	int s = sum(10,20);
	double d = sum(66.6, 33.3);
	
	return 0;
}


