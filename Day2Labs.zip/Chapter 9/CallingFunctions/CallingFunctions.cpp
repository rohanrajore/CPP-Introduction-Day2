#include <iostream>
using namespace std;

int Add2Int(int n1, int n2)
{
	int rslt;
	rslt = n1 + n2;
	return rslt;
}

int main(int argc, char** argv)
{
	int num1, num2;
	int result;
	int square;

	cout << "Enter 2 integers: ";
	cin >> num1 >> num2;
	result  = Add2Int(num1, num2);
	cout << num1 << " + " << num2 << " = " << result << endl;
	square = Add2Int(num1, num2) * Add2Int(num1, num2);
	cout << "(" << num1 << " + " << num2 << ") squared = " 
		 << square << endl;
		 
	return 0;
}



