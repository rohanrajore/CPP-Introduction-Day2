int __attribute__((always_inline)) add (int n1, int n2)
{
	return n1 + n2;
}

int main(int argc, char** argv)
{
	int x = add(10,20);
	return 0;
}


