//
// Static variables
//

#include <iostream>
using namespace std;

void accumulate(int num) 
{
   static int total;    // Value of total is retained
                        // between each function call
   total += num;
   cout << "total is " << total << endl;
}

int main(int argc, char** argv) 
{
   for (int i = 0; i < 5; ++i)
   {
      accumulate(i);
   }
   
   return 0;
}


