//
// scope resolution
//

#include <iostream>
using namespace std;

long total = 0;

void accumulate(int total)
{
	::total += total;
	{
		double total = ::total;
		cout << total << endl;
	}
}
