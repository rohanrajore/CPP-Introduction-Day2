#include <iostream>
using namespace std;

void powers(int number, int& square, int& cube);

int main(int argc, char** argv)
{
	int n;
	int nsquared;
	int ncubed;

	cout << "Eneter an integer: ";
	cin >> n;
	powers(n, nsquared, ncubed);

	cout << n << " squared = " << nsquared << endl;
	cout << n << " cubed = " << ncubed << endl;
}

void powers(int number, int& square, int& cube)
{
	square = number * number;
	cube = square * number;
}
