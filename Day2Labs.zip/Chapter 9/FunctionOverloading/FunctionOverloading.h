//
// Function overloading
//

void Print(int number_of_pages);
void Print(int number_of_pages, int copies);

void Print(int number_of_pages);
void Print(int copies);

void Print(int number_of_pages);
int Print(int number_of_pages);
