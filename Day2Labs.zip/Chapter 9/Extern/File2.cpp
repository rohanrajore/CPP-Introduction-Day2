//
// File 2
//

#include <iostream>
using namespace std;

extern int file1var1;

void doit();

int main(int argc, char** argv)
{
	doit();
	extern int file1var2;
	cout << file1var1 << " " << file1var2 << endl;
}
