//
// File 1
//

#include <iostream>
using namespace std;

int file1var1 = 10;
extern int file1var2 = 20;

void doit()
{
	cout << file1var1 << " " << file1var2 << endl;
}
