//
// Passing arguments by value and reference
//

struct BigOne
{
	double one;
	double two;
	// lots more variables here
};

void dosomething(BigOne a);

void dosomethingelse(BigOne& refa);

void dosomethingdifferent(const BigOne& constrefa);
