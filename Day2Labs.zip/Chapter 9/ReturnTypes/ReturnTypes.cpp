#include <iostream>
using namespace std;

int returnvalue(int x)
{
	int y;
	y = x * x;
	return y;
}
int& returnref(int x)
{
	int y;
	y = x * x;
	return y;
}
int main(int argc, char** argv)
{
	int a = 10;
	int b;
	b = returnvalue(a);
	cout << b << endl;
	b = returnref(a);
	cout << b << endl;
	
	return 0;
}


